<?php

$url = $_SERVER['REQUEST_URI'];
$url = rtrim($url, '/');

if ($url === '/user') {
    include 'user.php';
} elseif ($url === '/view') {
    include 'view2.php';
} else {
    include 'home.php';  
}
?>

