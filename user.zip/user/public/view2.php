<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>User Form</title>
    <link rel="stylesheet" href="view.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <style type='text/css'>
    
    </style>
</head>

<body>

    <div class='form'>
        <form method='post' id='user-form'>
            <h3 class='title'>User - Form </h3>

            <p class='success-message'></p>
            <p class='message'></p>

            <table width='400' cellpadding='12' align='center' cellspacing='1'>
                <tr>
                    <td>Name:</td>
                    <td><input name='name' type='text' id='name' class='input'></td>
                </tr>
                <tr>
                    <td>Age: </td>
                    <td><input name='age' type='number' id='age' class='input'></td>
                </tr>
                <tr>
                    <td>Email: </td>
                    <td><input name='email' type='text' id='email' class='input'></td>
                </tr>
                <tr>
                    <td></td>
                    <br>
                    <td><input type='submit' name='Submit' value='Submit' class='submit'></td>
                </tr>
            </table>
        </form>
    </div>

    <div class='table'>
        <h3 class='title'>User - Details </h3>
        <table id='user-details-table' border='1' style='width: 100%; border-collapse: collapse;'>
            <thead>
                <tr>
                    <th style='text-align:center; padding: 6px;'>ID</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Email</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>

 
    
    <script>
        $(document).ready(function () {
            
            function updateTable(userDetails) {
              
                $('#user-details-table tbody').empty();

                $.each(userDetails, function (index, row) {
                    $('#user-details-table tbody').append(
                        `<tr>
                            <td style='text-align:center; padding: 6px;'>${row.id}</td>
                            <td style='text-align:center'>${row.name}</td>
                            <td style='text-align:center'>${row.age}</td>
                            <td style='text-align:center'>${row.email}</td>
                        </tr>`
                    );
                });
            }

        
            function fetchUserDetails() {
                $.ajax({
                    type: 'GET',
                    url: '../src/controllers/newuser.php?action=get_user_details',
                    dataType: 'json',
                    success: function (data) {
                        updateTable(data);
                    },
                    error: function () {
                        alert('Error fetching user details.');
                    }
                });
            }

            fetchUserDetails();

        });
    </script>


</body>

</html>
